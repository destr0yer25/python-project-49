### Hexlet tests and linter status:
[![Actions Status](https://github.com/destr0yer25/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/destr0yer25/python-project-49/actions)
### CodeClimate
[![Maintainability](https://api.codeclimate.com/v1/badges/e5b97727f34d7a2bb0cd/maintainability)](https://codeclimate.com/github/destr0yer25/python-project-49/maintainability)
### Brain-even review of the game
[![asciicast](https://asciinema.org/a/UtleYckdvWf1nH4YEscxV4ccW.svg)](https://asciinema.org/a/UtleYckdvWf1nH4YEscxV4ccW)
### Brain-calc review of the game
[![asciicast](https://asciinema.org/a/uCRQ1qKMZ2wMsebGiDe4FbAjg.svg)](https://asciinema.org/a/uCRQ1qKMZ2wMsebGiDe4FbAjg)
